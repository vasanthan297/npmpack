import * as fs from 'fs';

interface Vulnerability {
    tool: string;
    severity: 'High' | 'Medium' | 'Low';
}

const vulnerabilities: Vulnerability[] = [
    { tool: 'Gitleaks', severity: 'High' },
    { tool: 'sonarqube', severity: 'High' }
    // Add more vulnerabilities as needed
];


// Define CSS styles
const cssStyles = `
    <style>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .header {
            background-color: #333;
            color: white;
            padding: 10px;
        }
        .section {
            margin: 20px;
            padding: 20px;
            border: 1px solid #ddd;
        }
        .vulnerability {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #f0ad4e;
            background-color: #fcf8e3;
        }
        .severity-high {
            color: #d9534f;
        }
        .severity-medium {
            color: #f0ad4e;
        }
        .severity-low {
            color: #5bc0de;
        }
    </style>
    </style>
`;


const vulnerabilitySections: string = vulnerabilities.map(vulnerability => `
    <div class="section">
        <h2>${vulnerability.tool}</h2>
        <div class="vulnerability severity-${vulnerability.severity.toLowerCase()}">
            <h3>${vulnerability.severity} Severity Vulnerability</h3>
        </div>
    </div>
`).join('');

const htmlReport: string = `
    <!DOCTYPE html>
    <html>
    <head>
        <title>Security Assessment Report</title>
        ${cssStyles}
    </head>
    <body>
        <div class="header">
            <h1>Security Summary</h1>
        </div>
        ${vulnerabilitySections}
    </body>
    </html>
`;

fs.writeFileSync('security-report.html', htmlReport);

console.log('Report generated successfully.');
